from .generalMenu.generalMenu import generalMenu
from .russianMenu.russianMenu import russianMenu

allDialogs = [
    generalMenu,
    russianMenu,
]